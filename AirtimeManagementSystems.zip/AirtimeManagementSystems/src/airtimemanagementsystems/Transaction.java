package airtimemanagementsystems;
import java.time.LocalDateTime;


public class Transaction {
    
     String clientName;
    double amount;
    LocalDateTime timestamp;

    public Transaction(String clientName, double amount) {
        this.clientName = clientName;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

     @Override
    public String toString() {
        return timestamp + " - " + clientName + ": R" + amount;
    }
}
