
package airtimemanagementsystems;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class AirtimeManagementSystems extends JFrame {

    private JTextField nameField, amountField;
    private JTextArea transactionArea;
    private JButton buyButton, clearButton;
    private ArrayList<Transaction> transactions;

    public AirtimeManagementSystems() {
        super("Airtime Management System");
        transactions = new ArrayList<>();

        JLabel nameLabel = new JLabel("Client Name:");
        JLabel amountLabel = new JLabel("Airtime Amount (R):");
        nameField = new JTextField(20);
        amountField = new JTextField(10);
        transactionArea = new JTextArea(10, 30);
        transactionArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(transactionArea);

        buyButton = new JButton("Buy Airtime");
        clearButton = new JButton("Clear History");

        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String amountText = amountField.getText().trim();
                if (name.isEmpty() || amountText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both client name and amount.");
                    return;
                }

                try {
                    double amount = Double.parseDouble(amountText);
                    Transaction transaction = new Transaction(name, amount);
                    transactions.add(transaction);
                    transactionArea.append(transaction + "\n");
                    nameField.setText("");
                    amountField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid amount. Please enter a number.");
                }
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                transactions.clear();
                transactionArea.setText("");
            }
        });

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2));
        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(amountLabel);
        inputPanel.add(amountField);
        inputPanel.add(buyButton);
        inputPanel.add(clearButton);

        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        new AirtimeManagementSystems();
    }
    
}
